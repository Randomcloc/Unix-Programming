/*
 * -----
 * Code by: Abhijeet Suryawanshi
 * Student Number: 19370773
 * Email: abhijeet.suryawanshi@ucdconnect.ie
 * -----
 */
#ifndef DATEPROMPT_H
#define DATEPROMPT_H

#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <limits.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

void prompt();

#endif 